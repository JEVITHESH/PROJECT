from flask import Flask, render_template, request, redirect, session
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'secret123'

def init_db():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        password TEXT NOT NULL
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        items TEXT,
        total INTEGER,
        datetime TEXT
    )''')
    conn.commit()
    conn.close()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
        conn.commit()
        conn.close()
        session['user'] = username
        session['cart'] = []
        return redirect('/')
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
        user = c.fetchone()
        conn.close()
        if user:
            session['user'] = username
            session['cart'] = []
            return redirect('/')
        return "Invalid credentials"
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return render_template('logout.html')

@app.route('/menu', methods=['GET', 'POST'])
def menu():
    items = [
        {"name": "Chocolate Cake", "price": 100, "image": "cake.jpg"},
        {"name": "Donut", "price": 40, "image": "donut.jpg"},
        {"name": "Coffee", "price": 50, "image": "coffee.jpg"}
    ]
    if request.method == 'POST' and 'user' in session:
        name, price = request.form['item'].split(":")
        cart = session.get('cart', [])
        cart.append({"name": name, "price": int(price)})
        session['cart'] = cart
    return render_template("menu.html", items=items)

@app.route('/cart')
def cart():
    return render_template("cart.html", cart=session.get("cart", []))

@app.route('/order_summary', methods=['POST'])
def order_summary():
    user = session.get('user', 'Guest')
    cart = session.get('cart', [])
    total = sum(item['price'] for item in cart)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if cart:
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("INSERT INTO orders (username, items, total, datetime) VALUES (?,?,?,?)",
                  (user, str(cart), total, now))
        conn.commit()
        conn.close()
        session['cart'] = []
    return render_template("order_summary.html", user=user, order={'items': cart, 'total': total, 'datetime': now})

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
