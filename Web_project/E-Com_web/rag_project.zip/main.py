from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from langchain_groq import ChatGroq
from langchain_core.messages import HumanMessage, SystemMessage
import os

# === Step 1: Load PDF ===
pdf_path = "MS-Dhoni-Biography.pdf"
loader = PyPDFLoader(pdf_path)
pdf_pages = loader.load()

# === Step 2: Split text ===
splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
docs = splitter.split_documents(pdf_pages)

# === Step 3: Embedding ===
embeddings = HuggingFaceEmbeddings(model_name="intfloat/multilingual-e5-large")

# === Step 4: Create or load VectorDB ===
vectordb = Chroma.from_documents(
    documents=docs,
    embedding=embeddings,
    persist_directory="./chroma_db"
)

# === Step 5: Query ===
question = "In which year did MS Dhoni receive the Padma Shri?"
results = vectordb.similarity_search(question, k=3)

# === Step 6: Setup Groq ===
os.environ["GROQ_API_KEY"] = input("Enter your GROQ API key: ")

llm = ChatGroq(
    model="meta-llama/llama-4-scout-17b-16e-instruct",
    temperature=0.2,
    max_tokens=250
)

# === Step 7: Format context ===
context = "\n\n".join([r.page_content for r in results])

# === Step 8: Ask the model ===
system_prompt = (
    "You are a helpful assistant for question-answering tasks. "
    "Use the context to answer briefly."
)
messages = [
    SystemMessage(content=system_prompt),
    HumanMessage(content=f"Context:\n{context}\n\nQuestion: {question}")
]

response = llm.invoke(messages)
print("\n🤖 Answer:", response.content)
